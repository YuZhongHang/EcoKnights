// screens/splash/splash_screen.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../routing/routes.dart';
import '../../services/firestore_service.dart';
import '../../models/user_model.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _checkAuthAndNavigate();
  }

  void _initializeAnimations() {
    _animationController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeIn,
    ));

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.elasticOut,
    ));

    _animationController.forward();
  }

  Future<void> _checkAuthAndNavigate() async {
    try {
      // Wait for animations to complete
      await Future.delayed(const Duration(seconds: 3));

      if (!mounted) return;

      // Check if user is authenticated
      User? firebaseUser = FirebaseAuth.instance.currentUser;
      
      if (firebaseUser == null) {
        // User not authenticated, go to login
        _navigateToLogin();
        return;
      }

      // Check if email is verified
      if (!firebaseUser.emailVerified) {
        // TODO: Navigate to email verification screen
        _navigateToLogin();
        return;
      }

      // Get user profile from Firestore
      UserModel? userProfile = await FirestoreService.getCurrentUserProfile();
      
      if (userProfile == null) {
        // User profile doesn't exist in Firestore, go to login
        _navigateToLogin();
        return;
      }

      // Update last login
      await FirestoreService.updateLastLogin();

      // Navigate based on user role
      if (userProfile.isAdmin) {
        _navigateToAdminHome();
      } else {
        _navigateToHome();
      }
    } catch (e) {
      debugPrint('Error during auth check: $e');
      _navigateToLogin();
    }
  }

  void _navigateToLogin() {
    if (mounted) {
      Navigator.of(context).pushReplacementNamed(Routes.loginScreen);
    }
  }

  void _navigateToHome() {
    if (mounted) {
      Navigator.of(context).pushReplacementNamed(Routes.home);
    }
  }

  void _navigateToAdminHome() {
    if (mounted) {
      Navigator.of(context).pushReplacementNamed(Routes.adminHome);
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade50,
      body: Center(
        child: AnimatedBuilder(
          animation: _animationController,
          builder: (context, child) {
            return FadeTransition(
              opacity: _fadeAnimation,
              child: ScaleTransition(
                scale: _scaleAnimation,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // App Logo
                    Container(
                      width: 120.w,
                      height: 120.h,
                      decoration: BoxDecoration(
                        color: Colors.blue.shade600,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.blue.withOpacity(0.3),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.security,
                        size: 60.sp,
                        color: Colors.white,
                      ),
                    ),
                    
                    SizedBox(height: 24.h),
                    
                    // App Name
                    Text(
                      'AuthBloc',
                      style: TextStyle(
                        fontSize: 32.sp,
                        fontWeight: FontWeight.bold,
                        color: Colors.blue.shade800,
                        letterSpacing: 2,
                      ),
                    ),
                    
                    SizedBox(height: 8.h),
                    
                    // App Tagline
                    Text(
                      'Secure Authentication System',
                      style: TextStyle(
                        fontSize: 16.sp,
                        color: Colors.blue.shade600,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    
                    SizedBox(height: 40.h),
                    
                    // Loading Indicator
                    SizedBox(
                      width: 40.w,
                      height: 40.h,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          Colors.blue.shade600,
                        ),
                      ),
                    ),
                    
                    SizedBox(height: 16.h),
                    
                    Text(
                      'Loading...',
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: Colors.blue.shade600,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}